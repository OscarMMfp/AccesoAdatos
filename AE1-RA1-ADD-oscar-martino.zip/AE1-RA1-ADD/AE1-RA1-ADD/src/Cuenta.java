import java.io.Serializable;
import java.util.ArrayList;
/**
 * representa una cuenta bancaria
 */
public class Cuenta implements Serializable {
    private static final long serialVersionUID = 1L;
    private Cliente cliente;
    private double saldo;
    private ArrayList<Movimiento> movimientos;
    /**
     * crea una cuenta nueva con saldo inicial 0
     *
     * @param cliente propietario de la cuenta
     */
    public Cuenta(Cliente cliente) {
        this.cliente = cliente;
        this.saldo = 0;
        this.movimientos = new ArrayList<>();
    }
    public Cliente getCliente() {
        return cliente;
    }
    public double getSaldo() {
        return saldo;
    }
    public ArrayList<Movimiento> getMovimientos() {
        return movimientos;
    }
    /**
     * realiza un ingreso de dinero
     *
     * @param importe cantidad ingresada
     * @param concepto concepto del ingreso
     */
    public void ingresar(double importe,String concepto) {
        if (importe<=0){
            throw new IllegalArgumentException("Importe invalido, debe ser mayor de 0");
        }
        saldo=saldo+importe;
        Movimiento movimiento= new Movimiento("INGRESO",concepto,importe,saldo);
        movimientos.add(movimiento);
    }
    /**
     * realiza una retirada de dinero
     *
     * @param importe cantidad retirada
     * @param concepto concepto de la retirada
     */
    public void retirar(double importe,String concepto) {
        if (importe<=0){
            throw new IllegalArgumentException("Importe invalido, debe ser mayor de 0");
        }else if (importe>saldo){
            throw new IllegalArgumentException("Importe invalido, debe ser menor que el saldo");
        }else{
            saldo=saldo-importe;
            Movimiento movimiento= new Movimiento("RETIRADA",concepto,importe,saldo);
            movimientos.add(movimiento);
        }
    }
    /**
     * muestra el saldo y los movimientos de la cuenta
     */
    public void mostrarInformacion(){
        System.out.println("Cuenta: ");
        System.out.println(cliente);
        System.out.printf("Saldo: "+saldo);
        System.out.println();
        System.out.println("Movimientos: ");
        if (movimientos.isEmpty()){
            System.out.println("No hay movimientos");
        }else{
            for (Movimiento movimiento : movimientos) {
                System.out.println(movimiento);
            }
        }
    }

}