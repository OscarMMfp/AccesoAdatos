import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
/**
 * representa un movimiento realizado en una cuenta
 */
public class Movimiento implements Serializable {
    private static final long serialVersionUID = 1L;
    private LocalDateTime fecha;
    private String tipo;
    private String concepto;
    private double importe;
    private double saldoRestante;
    /**
     * constructor de Movimiento
     *
     * @param tipo tipo de operación
     * @param concepto concepto de la operación
     * @param importe importe de la operación
     * @param saldo saldo después de la operación
     */
    public Movimiento(String tipo, String concepto, double importe, double saldo) {
        this.fecha = LocalDateTime.now();
        this.tipo = tipo;
        this.concepto = concepto;
        this.importe = importe;
        this.saldoRestante = saldo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public String getTipo() {
        return tipo;
    }

    public String getConcepto() {
        return concepto;
    }
    public double getImporte() {
        return importe;
    }

    public double getSaldoRestante() {
        return saldoRestante;
    }
    /**
     * muestra el movimiento en formato de texto
     *
     * @return movimiento formateado
     */
    @Override
    public String toString() {

        DateTimeFormatter formato =
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        return fecha.format(formato)
                + " | " + tipo
                + " | " + concepto
                + " | Importe: " + String.format("%.2f", importe) + " €"
                + " | Saldo: " + String.format("%.2f", saldoRestante) + " €";
    }
}