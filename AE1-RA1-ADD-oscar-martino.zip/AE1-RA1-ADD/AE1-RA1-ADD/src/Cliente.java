import java.io.Serializable;
/**
 * representa al cliente propietario de una cuenta bancaria
 */
public class Cliente implements Serializable {
    private static final long serialVersionUID = 1L;
    private String nombre;
    private String dni;
    private String telefono;
    /**
     * constructor de Cliente
     *
     * @param nombre nombre del cliente
     * @param dni DNI del cliente
     * @param telefono telefono del cliente
     */
    public Cliente(String nombre, String dni, String telefono) {
        this.nombre = nombre;
        this.dni = dni;
        this.telefono = telefono;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDni() {
        return dni;
    }
    public String getTelefono() {
        return telefono;
    }
    /**
     * devuelve los datos del cliente
     *
     * @return información del cliente
     */
    @Override
    public String toString() {
        return "Nombre: " + nombre +
                " | DNI: " + dni +
                " | Teléfono: " + telefono;
    }
}
