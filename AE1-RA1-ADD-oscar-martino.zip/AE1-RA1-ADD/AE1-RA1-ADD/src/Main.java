import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
/**
 * programa principal para gestionar una cuenta bancaria
 */
public class Main {
    private static final String CARPETA_DATOS = "datos";
    private static final String FICHERO_CUENTA = "datos/cuenta.dat";
    private static final String CARPETA_EXPORTACION = "exportacion";
    private static final String FICHERO_CSV ="exportacion/movimientos.csv";
    /**
     * Método principal.
     *
     * @param args argumentos del programa
     */
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        try {
            crearDirectorios();
            Cuenta cuenta = cargarCuenta();
            if (cuenta == null) {
                System.out.println("no existe una cuenta guardada");
                cuenta = crearCuenta(teclado);
            } else {
                System.out.println("cuenta recuperada correctamente");
            }
            mostrarMenu(teclado, cuenta);
            guardarCuenta(cuenta);
            System.out.println("\ncuenta guardada correctamente");
        } catch (IOException e) {
            System.out.println("error con los ficheros: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            teclado.close();
        }
    }
    /**
     * Crea los directorios necesarios.
     *
     * @throws IOException si no se pueden crear
     */
    public static void crearDirectorios() throws IOException {
        File datos = new File(CARPETA_DATOS);
        if (!datos.exists()) {
            if (!datos.mkdirs()) {
                throw new IOException("No se pudo crear la carpeta datos");
            }
        }
        File exportacion = new File(CARPETA_EXPORTACION);
        if (!exportacion.exists()) {
            if (!exportacion.mkdirs()) {
                throw new IOException("no se pudo crear la carpeta exportacion");
            }
        }
    }
    /**
     * Carga la cuenta desde cuenta.dat.
     *
     * @return cuenta recuperada o null si no existe
     * @throws IOException error de lectura
     * @throws ClassNotFoundException clase no encontrada
     */
    public static Cuenta cargarCuenta() throws IOException, ClassNotFoundException {
        File fichero = new File(FICHERO_CUENTA);
        if (!fichero.exists()) {
            return null;
        }
        ObjectInputStream entrada =new ObjectInputStream(new FileInputStream(fichero));
        Cuenta cuenta = (Cuenta) entrada.readObject();
        entrada.close();
        return cuenta;
    }
    /**
     * Guarda la cuenta en formato binario.
     *
     * @param cuenta cuenta que se va a guardar
     * @throws IOException error de escritura
     */
    public static void guardarCuenta(Cuenta cuenta) throws IOException {
        ObjectOutputStream salida =new ObjectOutputStream( new FileOutputStream(FICHERO_CUENTA) );
        salida.writeObject(cuenta);
        salida.close();
    }
    /**
     * Crea una cuenta nueva solicitando los datos del cliente.
     *
     * @param teclado scanner utilizado para leer datos
     * @return cuenta nueva
     */
    public static Cuenta crearCuenta(Scanner teclado) {
        System.out.println("crear cuenta:");
        System.out.print("Nombre: ");
        String nombre = teclado.nextLine();
        System.out.print("DNI: ");
        String dni = teclado.nextLine();
        System.out.print("Teléfono: ");
        String telefono = teclado.nextLine();
        Cliente cliente =new Cliente(nombre, dni, telefono);
        return new Cuenta(cliente);
    }
    /**
     * Muestra el menú principal.
     *
     * @param teclado scanner utilizado
     * @param cuenta cuenta que se gestiona
     */
    public static void mostrarMenu(Scanner teclado,Cuenta cuenta) {
        int opcion;
        do{
            System.out.println("Elige una opción: ");
            System.out.println("1. Ingresar dinero");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Consultar cuenta");
            System.out.println("4. Exportar movimientos");
            System.out.println("5. Salir");
            opcion = leerEntero(teclado,"Elige una opción: ");
            switch (opcion){
                case 1:
                    ingresar(teclado, cuenta);
                    break;
                case 2:
                    retirar(teclado, cuenta);
                    break;
                case 3:
                    cuenta.mostrarInformacion();
                    break;
                case 4:
                    exportarCSV(cuenta);
                    break;
                case 5:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("opción no válida");
            }
        }while (opcion!=5);
    }
    /**
     * Realiza un ingreso.
     *
     * @param teclado scanner
     * @param cuenta cuenta bancaria
     */
    public static void ingresar(Scanner teclado,Cuenta cuenta) {
        try {
            double importe =leerDouble(teclado,"Importe a ingresar: ");
            System.out.print("concepto: ");
            String concepto = teclado.nextLine();
            cuenta.ingresar(importe, concepto);
            System.out.printf("Ingreso realizado. Saldo: %.2f €%n",cuenta.getSaldo());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    /**
     * Realiza una retirada.
     *
     * @param teclado scanner
     * @param cuenta cuenta bancaria
     */
    public static void retirar(Scanner teclado,Cuenta cuenta){
        try {
            double importe =leerDouble(teclado,"importe a retirar: ");
            System.out.print("Concepto: ");
            String concepto = teclado.nextLine();
            cuenta.retirar(importe, concepto);
            System.out.printf("Retirada realizada, Saldo: %.2f €%n",cuenta.getSaldo());
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    /**
     * exporta los movimientos a CSV
     *
     * @param cuenta cuenta cuyos movimientos se exportan
     */
    public static void exportarCSV(Cuenta cuenta) {
        DateTimeFormatter formato =DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        try {
            BufferedWriter escritor =new BufferedWriter(new OutputStreamWriter(new FileOutputStream(FICHERO_CSV),StandardCharsets.UTF_8 ));
            escritor.write("Fecha,Tipo,Concepto,Importe,Saldo resultante");
            escritor.newLine();
            for (Movimiento movimiento :cuenta.getMovimientos()) {
                escritor.write("\"" +movimiento.getFecha().format(formato) +"\"," +"\"" +escaparCSV(movimiento.getTipo()) +
                                "\"," +"\"" +escaparCSV(movimiento.getConcepto()) +"\"," +String.format("%.2f",movimiento.getImporte()) +
                                "," +String.format("%.2f",movimiento.getSaldoRestante()) );
                escritor.newLine();
            }
            escritor.close();
            System.out.println("movimientos exportados correctamente");
            System.out.println("Fichero: " + FICHERO_CSV);
        }catch (IOException e) {
            System.out.println("Error al exportar: "+e.getMessage());
        }
    }
    /**
     * Evita problemas con comillas en un CSV.
     *
     * @param texto texto original
     * @return texto preparado para CSV
     */
    public static String escaparCSV(String texto) {

        return texto.replace("\"","\"\"");
    }
    /**
     * Lee un entero desde teclado.
     *
     * @param teclado scanner
     * @param mensaje mensaje que se muestra
     * @return número introducido
     */
    public static int leerEntero(Scanner teclado,String mensaje) {
        while (true){
            try {
                System.out.print(mensaje);
                return Integer.parseInt(teclado.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Introduce un número válido.");
            }
        }
    }
    /**
     * Lee un número decimal desde teclado.
     *
     * @param teclado scanner
     * @param mensaje mensaje que se muestra
     * @return número introducido
     */
    public static double leerDouble(Scanner teclado,String mensaje) {
        while (true) {
            try {
                System.out.print(mensaje);
                String texto =teclado.nextLine().replace(',', '.');
                return Double.parseDouble(texto);
            } catch (NumberFormatException e) {
                System.out.println("Introduce un importe válido.");
            }
        }
    }
}